-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2023 at 12:30 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbfoodsafety`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblblacklist`
--

CREATE TABLE `tblblacklist` (
  `bid` int(11) NOT NULL,
  `repId` int(11) NOT NULL,
  `bDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblblacklist`
--

INSERT INTO `tblblacklist` (`bid`, `repId`, `bDate`, `status`) VALUES
(1, 1, '2023-01-08 10:58:25', '1'),
(2, 2, '2023-02-05 11:46:23', '1'),
(3, 3, '2023-02-06 09:05:30', '1'),
(4, 4, '2023-02-06 09:22:13', '1'),
(5, 5, '2023-03-04 04:51:23', '1'),
(6, 6, '2023-03-04 05:18:47', '1'),
(7, 7, '2023-03-04 06:09:20', '1'),
(8, 10, '2023-03-04 10:58:39', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblfeedback`
--

CREATE TABLE `tblfeedback` (
  `fId` int(11) NOT NULL,
  `pId` int(11) NOT NULL,
  `rId` int(11) NOT NULL,
  `fDate` datetime NOT NULL,
  `feedback` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Submitted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfeedback`
--

INSERT INTO `tblfeedback` (`fId`, `pId`, `rId`, `fDate`, `feedback`, `status`) VALUES
(1, 1, 1, '2023-02-10 14:48:31', 'hasgdjhasdjgh', 'Replied'),
(2, 2, 1, '2023-02-03 00:00:00', 'asudg', 'Replied'),
(3, 1, 1, '2023-02-26 20:01:10', 'food quality is not good\r\n', 'Submitted');

-- --------------------------------------------------------

--
-- Table structure for table `tblinspection`
--

CREATE TABLE `tblinspection` (
  `inspId` int(11) NOT NULL,
  `iId` int(11) NOT NULL,
  `rId` int(11) NOT NULL,
  `inspDate` date NOT NULL,
  `inspRequest` varchar(500) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinspection`
--

INSERT INTO `tblinspection` (`inspId`, `iId`, `rId`, `inspDate`, `inspRequest`, `status`) VALUES
(1, 1, 1, '2023-01-09', 'Not clean', 'Completed'),
(2, 1, 1, '2023-03-09', 'inspection is required for this hospital', 'Completed'),
(3, 1, 3, '2023-03-06', 'inspection required for this hotel\r\n', 'Completed'),
(4, 2, 3, '2023-03-17', 'dcsdc', 'Completed'),
(5, 3, 4, '2023-03-07', 'inspection is required for this restaurant', 'Completed'),
(6, 3, 2, '2023-03-08', 'inspection required for this restaurant', 'Completed'),
(7, 2, 2, '2023-04-09', 'not cleann', 'Completed'),
(8, 2, 2, '2023-03-04', 'inspection  is required for this hotel not clean', 'Completed'),
(9, 4, 5, '2023-03-18', 'inspection is required  for the hotel', 'Completed'),
(10, 2, 5, '2023-03-19', 'unhygienic', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `tblinspector`
--

CREATE TABLE `tblinspector` (
  `iId` int(11) NOT NULL,
  `iName` varchar(50) NOT NULL,
  `iLicense` varchar(50) NOT NULL,
  `iAddress` varchar(100) NOT NULL,
  `iContact` varchar(50) NOT NULL,
  `iEmail` varchar(50) NOT NULL,
  `iImage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinspector`
--

INSERT INTO `tblinspector` (`iId`, `iName`, `iLicense`, `iAddress`, `iContact`, `iEmail`, `iImage`) VALUES
(1, 'Michael', 'kjn57', 'Aluva', '9632501479', 'michael@gmail.com', '../images/t1.jpg'),
(2, 'jhon', '1387457879084', 'aluva', '9388486899', 'jhon@gmail.com', '../images/c3.jpg'),
(3, 'rajesh', '8712309409126', 'thrissur', '7559905999', 'rajesh001@gmail.com', '../images/suresh.jpg'),
(4, 'ajithkumar', '1673245609142', 'thrissur', '9387476799', 'ajithkumar@gmail.com', '../images/insp.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE `tbllogin` (
  `lId` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`lId`, `username`, `password`, `usertype`, `status`) VALUES
(1, 'admin@gmail.com', 'admin', 'admin', '1'),
(2, 'iftharaluva@gmail.com', 'ifthar', 'restaurant', '1'),
(3, 'mathew@gmail.com', 'mathew', 'public', '1'),
(4, 'michael@gmail.com', '9632501478', 'inspector', '1'),
(5, 'theburgery@gmail.com', 'theburgery', 'restaurant', '1'),
(7, 'alex@gmail.com', 'alex', 'public', '1'),
(8, 'karthika@gmail.com', 'karthika', 'public', '1'),
(9, 'jhon@gmail.com', '9388486899', 'inspector', '1'),
(10, 'emperor123@gmail.com', 'Emperor123', 'restaurant', '1'),
(11, 'rajesh001@gmail.com', '7559905999', 'inspector', '1'),
(12, 'thaalkitchen@gmail.com', 'Thaalkitchen12', 'restaurant', '1'),
(13, 'ajithkumar@gmail.com', '9387476799', 'inspector', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblnotification`
--

CREATE TABLE `tblnotification` (
  `notId` int(11) NOT NULL,
  `notDate` date NOT NULL,
  `notification` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblnotification`
--

INSERT INTO `tblnotification` (`notId`, `notDate`, `notification`) VALUES
(1, '2023-01-08', 'kjnkjnkj'),
(2, '2023-02-06', 'hjgtfryedsdtfghj');

-- --------------------------------------------------------

--
-- Table structure for table `tblpenalty`
--

CREATE TABLE `tblpenalty` (
  `penaltyId` int(11) NOT NULL,
  `repId` int(11) NOT NULL,
  `duedate` date NOT NULL,
  `amt` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Assigned'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpenalty`
--

INSERT INTO `tblpenalty` (`penaltyId`, `repId`, `duedate`, `amt`, `status`) VALUES
(1, 1, '2023-03-04', 2000, 'Paid'),
(2, 2, '2023-03-11', 5000, 'Paid'),
(3, 3, '2023-03-08', 10000, 'Paid'),
(4, 4, '2023-03-20', 10000, 'Paid'),
(5, 5, '2023-03-09', 6000, 'Paid'),
(6, 6, '2023-03-10', 5000, 'Assigned'),
(7, 7, '2023-04-13', 9000, 'Paid'),
(8, 10, '2023-03-20', 8000, 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `tblpublic`
--

CREATE TABLE `tblpublic` (
  `pId` int(11) NOT NULL,
  `pName` varchar(50) NOT NULL,
  `pAddress` varchar(50) NOT NULL,
  `pEmail` varchar(50) NOT NULL,
  `pContact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpublic`
--

INSERT INTO `tblpublic` (`pId`, `pName`, `pAddress`, `pEmail`, `pContact`) VALUES
(1, 'Mathew', 'Aluva', 'mathew@gmail.com', '7485960231'),
(2, 'alex', 'methala', 'alex@gmail.com', '7558804999'),
(3, 'karthika', 'snpuram', 'karthika@gmail.com', '6208993478');

-- --------------------------------------------------------

--
-- Table structure for table `tblreply`
--

CREATE TABLE `tblreply` (
  `replyId` int(11) NOT NULL,
  `fId` int(11) NOT NULL,
  `reply` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreply`
--

INSERT INTO `tblreply` (`replyId`, `fId`, `reply`) VALUES
(1, 1, 'kjnmjkln'),
(2, 2, 'sdsfczx');

-- --------------------------------------------------------

--
-- Table structure for table `tblresponse`
--

CREATE TABLE `tblresponse` (
  `repId` int(11) NOT NULL,
  `inspId` int(11) NOT NULL,
  `repDate` date NOT NULL,
  `report` varchar(100) NOT NULL,
  `rating` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblresponse`
--

INSERT INTO `tblresponse` (`repId`, `inspId`, `repDate`, `report`, `rating`) VALUES
(1, 1, '2023-01-08', 'kjnkijni', 2),
(2, 2, '2023-02-05', 'not clean', 2),
(3, 3, '2023-02-06', 'not clean\r\n', 1),
(4, 4, '2023-02-06', 'erfref', 2),
(5, 5, '2023-03-04', 'hotel food quality is low', 2),
(6, 6, '2023-03-04', 'not good', 2),
(7, 7, '2023-03-04', 'unhygienic', 1),
(8, 8, '2023-03-04', 'hvvvvvvgjv', 3),
(9, 9, '2023-03-04', 'good  quality food and hygienic', 4),
(10, 10, '2023-03-04', 'unhygienic and not clean', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblrestaurant`
--

CREATE TABLE `tblrestaurant` (
  `rId` int(11) NOT NULL,
  `rName` varchar(50) NOT NULL,
  `rAddress` varchar(100) NOT NULL,
  `rEmail` varchar(50) NOT NULL,
  `rContact` varchar(50) NOT NULL,
  `rLicense` varchar(50) NOT NULL,
  `rImage` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrestaurant`
--

INSERT INTO `tblrestaurant` (`rId`, `rName`, `rAddress`, `rEmail`, `rContact`, `rLicense`, `rImage`) VALUES
(1, 'Ifthar Aluva', 'Aluva', 'iftharaluva@gmail.com', '9568740231', 'jn85787', '../images/b6.jpg'),
(2, 'Theburgery', 'kodungallur', 'theburgery@gmail.com', '8301092199', '128743982367', '../images/rest1.jpg'),
(4, 'emperor', 'kodungallur ,bypass', 'emperor123@gmail.com', '7559905993', '13874566935324', '../images/emperor.jpeg'),
(5, 'thaal kitchen', 'aluva', 'thaalkitchen@gmail.com', '9496470098', '1896346789064', '../images/thaal.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblblacklist`
--
ALTER TABLE `tblblacklist`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `tblfeedback`
--
ALTER TABLE `tblfeedback`
  ADD PRIMARY KEY (`fId`);

--
-- Indexes for table `tblinspection`
--
ALTER TABLE `tblinspection`
  ADD PRIMARY KEY (`inspId`);

--
-- Indexes for table `tblinspector`
--
ALTER TABLE `tblinspector`
  ADD PRIMARY KEY (`iId`);

--
-- Indexes for table `tbllogin`
--
ALTER TABLE `tbllogin`
  ADD PRIMARY KEY (`lId`);

--
-- Indexes for table `tblnotification`
--
ALTER TABLE `tblnotification`
  ADD PRIMARY KEY (`notId`);

--
-- Indexes for table `tblpenalty`
--
ALTER TABLE `tblpenalty`
  ADD PRIMARY KEY (`penaltyId`);

--
-- Indexes for table `tblpublic`
--
ALTER TABLE `tblpublic`
  ADD PRIMARY KEY (`pId`);

--
-- Indexes for table `tblreply`
--
ALTER TABLE `tblreply`
  ADD PRIMARY KEY (`replyId`);

--
-- Indexes for table `tblresponse`
--
ALTER TABLE `tblresponse`
  ADD PRIMARY KEY (`repId`);

--
-- Indexes for table `tblrestaurant`
--
ALTER TABLE `tblrestaurant`
  ADD PRIMARY KEY (`rId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblblacklist`
--
ALTER TABLE `tblblacklist`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblfeedback`
--
ALTER TABLE `tblfeedback`
  MODIFY `fId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblinspection`
--
ALTER TABLE `tblinspection`
  MODIFY `inspId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblinspector`
--
ALTER TABLE `tblinspector`
  MODIFY `iId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbllogin`
--
ALTER TABLE `tbllogin`
  MODIFY `lId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblnotification`
--
ALTER TABLE `tblnotification`
  MODIFY `notId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpenalty`
--
ALTER TABLE `tblpenalty`
  MODIFY `penaltyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblpublic`
--
ALTER TABLE `tblpublic`
  MODIFY `pId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblreply`
--
ALTER TABLE `tblreply`
  MODIFY `replyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblresponse`
--
ALTER TABLE `tblresponse`
  MODIFY `repId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblrestaurant`
--
ALTER TABLE `tblrestaurant`
  MODIFY `rId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
